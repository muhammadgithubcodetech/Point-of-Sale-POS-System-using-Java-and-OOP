package com.mycompany.mavenproject12;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

class Product implements Serializable {
    private static final long serialVersionUID = 1L;

    private int id;
    private String name;
    private double costPrice;
    private double salePrice;
    private int quantity;

    public Product(int id, String name, double costPrice, double salePrice, int quantity) {
        this.id = id;
        this.name = name;
        this.costPrice = costPrice;
        this.salePrice = salePrice;
        this.quantity = quantity;
    }

    public String toString() {
        return String.format("%-10d%-20s%-15.2f%-15.2f%-10d", id, name, costPrice, salePrice, quantity);
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getCostPrice() {
        return costPrice;
    }

    public void setCostPrice(double costPrice) {
        this.costPrice = costPrice;
    }

    public double getSalePrice() {
        return salePrice;
    }

    public void setSalePrice(double salePrice) {
        this.salePrice = salePrice;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String ProductDetails() {
        return "Product{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", costPrice=" + costPrice +
                ", salePrice=" + salePrice +
                ", quantity=" + quantity +
                '}';
    }
}

class Inventory {
    private static final String FILE_NAME = "products.dat";
    private ArrayList<Product> products;

    public Inventory() {
        this.products = new ArrayList<>();
        initializeProducts();
    }

    private void initializeProducts() {
        loadProducts();
        if (products.isEmpty()) {
            products.add(new Product(1, "T-shirt", 10.0, 15.0, 300));
            products.add(new Product(2, "Jeans", 20.0, 30.0, 300));
            products.add(new Product(3, "Hoodie", 25.0, 40.0, 300));
            products.add(new Product(4, "Cap", 5.0, 10.0, 300));
            products.add(new Product(5, "Scarf", 7.0, 12.0, 300));
            products.add(new Product(6, "Shorts", 15.0, 22.0, 300));
            products.add(new Product(7, "Cheenos", 18.0, 25.0, 300));
            products.add(new Product(8, "Trousers", 22.0, 35.0, 300));
        }
    }

    public void addProduct(Product product) {
        products.add(product);
        saveProducts();
    }

    public Product selectProductByID(int ID) {
        for (Product product : products) {
            if (product.getId() == ID) {
                if (product.getQuantity() > 0) {
                    product.setQuantity(product.getQuantity() - 1);
                    saveProducts();
                    return product;
                } else return null;
            }
        }
        return null;
    }

    public void increaseQuantity(int Id, int quantity) {
        for (Product product : products) {
            if (product.getId() == Id) {
                product.setQuantity(product.getQuantity() + quantity);
                saveProducts();
                break;
            }
        }
    }

    public void updateProduct(int id, String name, double costPrice, double salePrice, int quantity) {
        for (Product product : products) {
            if (product.getId() == id) {
                product.setName(name);
                product.setCostPrice(costPrice);
                product.setSalePrice(salePrice);
                product.setQuantity(quantity);
                saveProducts();
                break;
            }
        }
    }

    public void deleteProduct(int id) {
        Iterator<Product> iterator = products.iterator();
        while (iterator.hasNext()) {
            Product product = iterator.next();
            if (product.getId() == id) {
                iterator.remove();
                saveProducts();
                break;
            }
        }
    }

    public ArrayList<Product> getProducts() {
        return products;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (Product product : products) {
            sb.append(product).append("\n");
        }
        return sb.toString();
    }

    public void saveProducts() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(FILE_NAME))) {
            oos.writeObject(products);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @SuppressWarnings("unchecked")
    public void loadProducts() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(FILE_NAME))) {
            products = (ArrayList<Product>) ois.readObject();
        } catch (FileNotFoundException e) {
            System.out.println("Product file not found, initializing with default products.");
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}

class Sales {
    private ArrayList<Product> cart;
    private double total;
    private double costTotal;

    public Sales() {
        this.cart = new ArrayList<>();
        this.total = 0.0;
        this.costTotal = 0.0;
    }

    public void addToCart(Product product) {
        cart.add(product);
        total += product.getSalePrice();
        costTotal += product.getCostPrice();
    }

    public double calculateTotal() {
        return total;
    }

    public double calculateProfit() {
        return total - costTotal;
    }

    public String generateReceipt() {
        StringBuilder receipt = new StringBuilder();
        receipt.append("Receipt:\n");
        for (Product product : cart) {
            receipt.append(product.getName()).append(": $").append(product.getSalePrice()).append("\n");
        }
        receipt.append("Total: $").append(total).append("\n");
        receipt.append("Profit: $").append(calculateProfit());
        return receipt.toString();
    }

    public void checkout() {
        try (FileWriter fw = new FileWriter("receipts.txt", true);
             BufferedWriter bw = new BufferedWriter(fw);
             PrintWriter out = new PrintWriter(bw)) {
            out.println(generateReceipt());
            out.println("-------------------------------");
        } catch (IOException e) {
            e.printStackTrace();
        }
        cart.clear();
        total = 0.0;
        costTotal = 0.0;
    }

    public String viewCart() {
        StringBuilder sb = new StringBuilder();
        for (Product prod : cart) {
            sb.append(prod).append("\n");
        }
        return sb.toString();
    }

    public List<Product> getCart() {
        return cart;
    }
}

class ReadReceiptsFile {
    String fileName = "receipts.txt";

    public void read() {
        try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = br.readLine()) != null) {
                System.out.println(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

class UserAuthentication {
    private static final String USER_FILE = "users.txt.txt";
    private List<String> users;

    public UserAuthentication() {
        this.users = loadUsers();
    }

    private List<String> loadUsers() {
        List<String> userList = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(USER_FILE))) {
            String line;
            while ((line = br.readLine()) != null) {
                userList.add(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return userList;
    }

    public boolean authenticate(String username, String password) {
        for (String user : users) {
            String[] userDetails = user.split(" ");
            if (userDetails[0].equals(username) && userDetails[1].equals(password)) {
                return true;
            }
        }
        return false;
    }

    public boolean isAdmin(String username) {
        return username.equals("admin");
    }

    public void deleteUser(String username) {
        Iterator<String> iterator = users.iterator();
        while (iterator.hasNext()) {
            String user = iterator.next();
            if (user.split(" ")[0].equals(username)) {
                iterator.remove();
                saveUsers();
                break;
            }
        }
    }

    private void saveUsers() {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(USER_FILE))) {
            for (String user : users) {
                bw.write(user);
                bw.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

public class oop_project extends JFrame {
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton loginButton;
    private JButton exitButton;
    private JTextArea textArea;
    private Inventory inventory;
    private Sales sales;
    private UserAuthentication userAuth;
    private JPanel adminPanel;
    private JPanel userPanel;

    public oop_project() {
        inventory = new Inventory();
        sales = new Sales();
        userAuth = new UserAuthentication();
        initializeUI();
    }

  private void initializeUI() {
    setTitle("Login Page");
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setSize(400, 300);
    setLocationRelativeTo(null);
    setLayout(new BorderLayout());

    JPanel panel = new JPanel();
    panel.setLayout(null); // Use null layout

    JLabel usernameLabel = new JLabel("Username:");
    usernameLabel.setBounds(50, 50, 80, 25); // Set bounds for label
    usernameField = new JTextField();
    usernameField.setBounds(140, 50, 200, 25); // Set bounds for text field
    JLabel passwordLabel = new JLabel("Password:");
    passwordLabel.setBounds(50, 90, 80, 25); // Set bounds for label
    passwordField = new JPasswordField();
    passwordField.setBounds(140, 90, 200, 25); // Set bounds for text field
    loginButton = new JButton("Login");
    loginButton.setBounds(100, 130, 80, 30); // Set bounds for login button
    exitButton = new JButton("Exit");
    exitButton.setBounds(220, 130, 80, 30); // Set bounds for exit button

    loginButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            handleLogin();
        }
    });

    exitButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            System.exit(0);
        }
    });

    panel.add(usernameLabel);
    panel.add(usernameField);
    panel.add(passwordLabel);
    panel.add(passwordField);
    panel.add(loginButton);
    panel.add(exitButton);

    textArea = new JTextArea();
    textArea.setEditable(false);
    JScrollPane scrollPane = new JScrollPane(textArea);
    scrollPane.setBounds(50, 170, 290, 80); // Set bounds for scroll pane

    add(panel, BorderLayout.CENTER);
    add(scrollPane, BorderLayout.SOUTH);

    adminPanel = new JPanel();
    userPanel = new JPanel();

    initializeAdminPanel();
    initializeUserPanel();
}



    private void handleLogin() {
        String username = usernameField.getText();
        String password = new String(passwordField.getPassword());

        if (userAuth.authenticate(username, password)) {
            if (userAuth.isAdmin(username)) {
                showAdminPanel();
            } else {
                showUserPanel();
            }
        } else {
            JOptionPane.showMessageDialog(this, "Invalid username or password.", "Login Failed", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void showAdminPanel() {
        setTitle("Admin Panel");
        remove(loginButton.getParent());
        add(adminPanel, BorderLayout.CENTER);
        validate();
        repaint();
    }

    private void showUserPanel() {
        setTitle("User Panel");
        remove(loginButton.getParent());
        add(userPanel, BorderLayout.CENTER);
        validate();
        repaint();
    }

    private void initializeAdminPanel() {
        adminPanel.setLayout(new BorderLayout());

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(6, 1, 10, 10));

        JButton addProductButton = new JButton("Add Product");
        JButton updateProductButton = new JButton("Update Product");
        JButton deleteProductButton = new JButton("Delete Product");
        JButton viewInventoryButton = new JButton("View Inventory");
        JButton increaseQuantityButton = new JButton("Increase Quantity");
        JButton exitButton = new JButton("Exit");

        addProductButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addProduct();
            }
        });

        updateProductButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updateProduct();
            }
        });

        deleteProductButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                deleteProduct();
            }
        });

        viewInventoryButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                viewInventory();
            }
        });

        increaseQuantityButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                increaseQuantity();
            }
        });

        exitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });

        panel.add(addProductButton);
        panel.add(updateProductButton);
        panel.add(deleteProductButton);
        panel.add(viewInventoryButton);
        panel.add(increaseQuantityButton);
        panel.add(exitButton);

        adminPanel.add(panel, BorderLayout.CENTER);
    }

    private void initializeUserPanel() {
        userPanel.setLayout(new BorderLayout());

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(4, 1, 10, 10));

        JButton addToCartButton = new JButton("Add to Cart");
        JButton viewCartButton = new JButton("View Cart");
        JButton checkoutButton = new JButton("Checkout");
        JButton exitButton = new JButton("Exit");
        JButton viewInventoryButton = new JButton("View Inventory");
        
        
        viewInventoryButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                viewInventory();
            }
        });
        
        addToCartButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addToCart();
            }
        });

        viewCartButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                viewCart();
            }
        });

        checkoutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                checkout();
            }
        });

        exitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
        

        panel.add(addToCartButton);
        panel.add(viewCartButton);
        panel.add(checkoutButton);
        panel.add(viewInventoryButton);
        panel.add(exitButton);

        userPanel.add(panel, BorderLayout.CENTER);
    }

    private void addProduct() {
        JTextField idField = new JTextField();
        JTextField nameField = new JTextField();
        JTextField costPriceField = new JTextField();
        JTextField salePriceField = new JTextField();
        JTextField quantityField = new JTextField();

        Object[] message = {
                "ID:", idField,
                "Name:", nameField,
                "Cost Price:", costPriceField,
                "Sale Price:", salePriceField,
                "Quantity:", quantityField
        };

        int option = JOptionPane.showConfirmDialog(this, message, "Add Product", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            try {
                int id = Integer.parseInt(idField.getText());
                String name = nameField.getText();
                double costPrice = Double.parseDouble(costPriceField.getText());
                double salePrice = Double.parseDouble(salePriceField.getText());
                int quantity = Integer.parseInt(quantityField.getText());

                Product product = new Product(id, name, costPrice, salePrice, quantity);
                inventory.addProduct(product);
                JOptionPane.showMessageDialog(this, "Product added successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Invalid input. Please enter valid data.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void updateProduct() {
        JTextField idField = new JTextField();
        JTextField nameField = new JTextField();
        JTextField costPriceField = new JTextField();
        JTextField salePriceField = new JTextField();
        JTextField quantityField = new JTextField();

        Object[] message = {
                "ID:", idField,
                "Name:", nameField,
                "Cost Price:", costPriceField,
                "Sale Price:", salePriceField,
                "Quantity:", quantityField
        };

        int option = JOptionPane.showConfirmDialog(this, message, "Update Product", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            try {
                int id = Integer.parseInt(idField.getText());
                String name = nameField.getText();
                double costPrice = Double.parseDouble(costPriceField.getText());
                double salePrice = Double.parseDouble(salePriceField.getText());
                int quantity = Integer.parseInt(quantityField.getText());

                inventory.updateProduct(id, name, costPrice, salePrice, quantity);
                JOptionPane.showMessageDialog(this, "Product updated successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Invalid input. Please enter valid data.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void deleteProduct() {
        JTextField idField = new JTextField();

        Object[] message = {
                "ID:", idField
        };

        int option = JOptionPane.showConfirmDialog(this, message, "Delete Product", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            try {
                int id = Integer.parseInt(idField.getText());
                inventory.deleteProduct(id);
                JOptionPane.showMessageDialog(this, "Product deleted successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Invalid input. Please enter a valid ID.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void increaseQuantity() {
        JTextField idField = new JTextField();
        JTextField quantityField = new JTextField();

        Object[] message = {
                "ID:", idField,
                "Quantity:", quantityField
        };

        int option = JOptionPane.showConfirmDialog(this, message, "Increase Quantity", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            try {
                int id = Integer.parseInt(idField.getText());
                int quantity = Integer.parseInt(quantityField.getText());
                inventory.increaseQuantity(id, quantity);
                JOptionPane.showMessageDialog(this, "Quantity increased successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Invalid input. Please enter valid data.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void viewInventory() {
        StringBuilder inventoryDetails = new StringBuilder();
        for (Product product : inventory.getProducts()) {
            inventoryDetails.append(product.toString()).append("\n");
        }
        textArea.setText(inventoryDetails.toString());
    }

    private void addToCart() {
        JTextField idField = new JTextField();

        Object[] message = {
                "ID:", idField
        };

        int option = JOptionPane.showConfirmDialog(this, message, "Add to Cart", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            try {
                int id = Integer.parseInt(idField.getText());
                Product product = inventory.selectProductByID(id);
                if (product != null) {
                    sales.addToCart(product);
                    JOptionPane.showMessageDialog(this, "Product added to cart.", "Success", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(this, "Product not found.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Invalid input. Please enter a valid ID.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void viewCart() {
        StringBuilder cartDetails = new StringBuilder();
        for (Product product : sales.getCart()) {
            cartDetails.append(product.toString()).append("\n");
        }
        cartDetails.append("Total: ").append(sales.calculateTotal()).append("\n");
        textArea.setText(cartDetails.toString());
    }

    private void checkout() {
        double total = sales.calculateTotal();
        JOptionPane.showMessageDialog(this, "Total amount: " + total, "Checkout", JOptionPane.INFORMATION_MESSAGE);
        sales.checkout();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new oop_project().setVisible(true);
            }
        });
    }
}